:orphan:

Playbook Roles and Include Statements
=====================================

.. contents:: Topics


The documentation regarding roles and includes for playbooks have moved. Their new location is here: :doc:`playbooks_reuse`. Please update any links you may have made directly to this page.

.. seealso::

   :ref:`ansible_galaxy`
       How to share roles on galaxy, role management
   :ref:`working_with_playbooks`
       Review the basic Playbook language features
   :ref:`playbooks_reuse`
       Creating reusable Playbooks.

